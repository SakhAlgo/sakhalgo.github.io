## Материалы, которые могут быть полезны:
💡 [Сайт на Wordpress, Верстка сайта и перенос на CMS](https://stepik.org/course/113393) в этом бесплатном курсе доступны задания и еще больше полезных материалов    
💾 [Скачать макет Figma](fragment_1.fig)  
🎥 [Обзор, настройка и плагины редактора VS Code](https://youtu.be/-U9wsHNOWgk)  
🎥 [Подробнее про box-sizing](https://youtu.be/9prTwMLJQC8)  
🎥 [Видео о том, как выровнять картинку по центру на CSS разными способами](https://youtu.be/nFaBNwKGqC0?si=ZaQ0JUt4jI-WKgyP)  
🎥 [Подробный урок про Flexbox](https://youtu.be/Hf__JLlFxpk)  
📌 [Расширение Perfect Pixel для браузера Chrome](https://chromewebstore.google.com/detail/dkaagdgjmgdmbnecmcefdhjekcoceebi)  
📌 [Расширение VS HTML to CSS](https://marketplace.visualstudio.com/items?itemName=neptunedesign.vs-html-to-css)  
⚙️ [Генератор тени и другие инструменты онлайн](https://morphismail.github.io/myInstruments/)  
💡 [Курс по Git и GitHub](https://stepik.org/101092) (эти материалы также включены в [курс Frontend разработчик](https://stepik.org/113402), поэтому выбирайте только одни из этих курсов)  
⚡️ [Скачать макеты для практики](https://t.me/tasks_by_code)  